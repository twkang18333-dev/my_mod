﻿using HarmonyLib;
using MCM.Abstractions.Base.Global;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using TaleWorlds.CampaignSystem;
using TaleWorlds.CampaignSystem.CharacterDevelopment;
using TaleWorlds.CampaignSystem.GameComponents;
using TaleWorlds.CampaignSystem.MapEvents;
using TaleWorlds.CampaignSystem.Party;
using TaleWorlds.CampaignSystem.ViewModelCollection;
using TaleWorlds.CampaignSystem.ViewModelCollection.Encyclopedia;
using TaleWorlds.CampaignSystem.ViewModelCollection.Encyclopedia.Items;
using TaleWorlds.CampaignSystem.ViewModelCollection.Party;
using TaleWorlds.Core;
using TaleWorlds.Core.ViewModelCollection.Generic;
using TaleWorlds.Localization;
using TaleWorlds.MountAndBlade;
using static TroopTierTweaks.SubModule;

namespace TroopTierTweaks
{
    public class SubModule : MBSubModuleBase
    {
        protected override void OnGameStart(Game game, IGameStarter starter)
        {
            base.OnGameStart(game, starter);
            Trace.WriteLine("TroopTierTweaks OnGameStart");

            try
            {
                var harmony = new Harmony("com.example.bannerlord.tiertweaks");
                harmony.PatchAll();
                Trace.WriteLine("TroopTierTweaks 패치 적용 완료");
            }
            catch (Exception ex)
            {
                Trace.WriteLine("TroopTierTweaks 패치 적용 실패: " + ex);
            }
        }
    }

    // 티어별 경험치 설정
    public static class TierXpConfig
    {
        public static readonly Dictionary<int, int> TierXp = new Dictionary<int, int>
        {
            { 1, 200 },
            { 2, 500 },
            { 3, 1000 },
            { 4, 1800 },
            { 5, 2800 },
            { 6, 10000 },
            { 7, 40000 },
            { 8, 200000 },
            { 9, 900000 },
            { 10, 2600000 }, // 10티어 추가
            { 11, 3000000 }, // 11티어 추가
            { 12, 6000000 }  // 12티어 추가
        };

        public static int GetTierByLevel(int level)
        {
            if (level >= 61) return 12;
            if (level >= 56) return 11;
            if (level >= 51) return 10;
            if (level >= 46) return 9;
            if (level >= 41) return 8;
            if (level >= 36) return 7;
            if (level >= 31) return 6;
            if (level >= 26) return 5;
            if (level >= 21) return 4;
            if (level >= 16) return 3;
            if (level >= 11) return 2;
            return 1;
        }
    }

    // GetUpgradeXpCost 패치
    [HarmonyPatch(typeof(CharacterObject), "GetUpgradeXpCost")]
    public class Patch_GetUpgradeXpCost
    {
        static bool Prefix(CharacterObject __instance, ref int __result)
        {
            int tier = __instance.Tier;
            if (TierXpConfig.TierXp.TryGetValue(tier, out int xp))
                __result = xp;
            else
                __result = 0;

            return false; // 원본 실행 안 함
        }
    }

    // CharacterObject.Tier Postfix 패치
    [HarmonyPatch(typeof(CharacterObject), "get_Tier")]
    public class Patch_CharacterObject_Tier
    {
        static void Postfix(CharacterObject __instance, ref int __result)
        {
            int level = __instance.Level;
            int newTier = TierXpConfig.GetTierByLevel(level);

            //Trace.WriteLine("[TroopTierTweaks] Patch_CharacterObject_Tier level " + level + ", newTier " + newTier);

            if (newTier > __result) __result = newTier;
            if (__result == 8) __result = 8;
            if (__result == 9) __result = 9;
            if (__result == 10) __result = 10;
            if (__result == 11) __result = 11;
            if (__result == 12) __result = 12;
        }
    }

    // CampaignUIHelper.GetCharacterTierData 덮어쓰기
    [HarmonyPatch(typeof(CampaignUIHelper), "GetCharacterTierData")]
    public class GetCharacterTierDataPatch
    {
        private static bool Prefix(ref StringItemWithHintVM __result, CharacterObject character, bool isBig = false)
        {
            int tier = character.Tier;

            // 8티어만 커스텀 아이콘 적용
            if (tier >= 8)
            {
                //Trace.WriteLine("[TroopTierTweaks] Custom 8-tier icon applied. isBig = " + isBig);
                GameTexts.SetVariable("TIER_LEVEL", tier);
                TextObject textObject = new TextObject("{=!}" + GameTexts.FindText("str_party_troop_tier").ToString());

                string tierIconPath = "General\\TroopTierIcons\\ttt_icon_" + tier;
                __result = new StringItemWithHintVM(tierIconPath, textObject);

                return false;   // 원래 메서드 실행 안함 (커스텀 아이콘 사용
            }
            //else if (tier == 9)
            //{
            //    //Trace.WriteLine("[TroopTierTweaks] Custom 9-tier icon applied. isBig = " + isBig);
            //    GameTexts.SetVariable("TIER_LEVEL", tier);
            //    TextObject textObject = new TextObject("{=!}" + GameTexts.FindText("str_party_troop_tier").ToString());

            //    string tierIconPath = "General\\TroopTierIcons\\ttt_icon_9";
            //    __result = new StringItemWithHintVM(tierIconPath, textObject);

            //    return false;   // 원래 메서드 실행 안함 (커스텀 아이콘 사용
            //}
            //else if (tier == 10)
            //{
            //    //Trace.WriteLine("[TroopTierTweaks] Custom 10-tier icon applied. isBig = " + isBig);
            //    GameTexts.SetVariable("TIER_LEVEL", tier);
            //    TextObject textObject = new TextObject("{=!}" + GameTexts.FindText("str_party_troop_tier").ToString());

            //    string tierIconPath = "General\\TroopTierIcons\\ttt_icon_10";
            //    __result = new StringItemWithHintVM(tierIconPath, textObject);

            //    return false;   // 원래 메서드 실행 안함 (커스텀 아이콘 사용
            //}

            // 1~7티어는 원래 기능 그대로 사용
            return true;
            // => 원본 GetCharacterTierData 실행됨
        }
    }


    // 임금 set
    [HarmonyPatch(typeof(DefaultPartyWageModel), "GetCharacterWage")]
    public class GetCharacterWagePatch
    {
        private static bool Prefix(ref int __result, CharacterObject character)
        {
            int tier = character.Tier;
            bool flag = tier < GetCharacterWagePatch.wages.Length;
            if (flag)
            {
                __result = GetCharacterWagePatch.wages[tier];
            }
            else
            {
                __result = GetCharacterWagePatch.CalculateHigherTierWage(tier);
            }
            bool flag2 = character.Occupation == Occupation.Mercenary;
            if (flag2)
            {
                __result = (int)((float)__result * 1.5f);
            }
            return false;
        }

        private static int CalculateHigherTierWage(int tier)
        {
            int num = 192;
            int num2 = num;
            for (int i = 21; i <= tier; i++)
            {
                num2 += i - 1;
            }
            return num2;
        }

        private static readonly int[] wages = new int[]
        {
            1,
            2,
            3,
            5,
            8,
            12,
            25,
            43,
            100,
            250,
            1000, // 10등급
            4000,
            10000,
            18000,
            20000,
            30000,
            60000,
        };
    }



    // 기본 비용 set
    [HarmonyPatch(typeof(DefaultPartyWageModel))]
    public class TroopTierCostPatch
    {
        // 기존 GetTroopRecruitmentCost 완전 대체
        [HarmonyPrefix]
        [HarmonyPatch("GetTroopRecruitmentCost")]
        public static bool Prefix(
            CharacterObject troop,
            Hero buyerHero,
            bool withoutItemCost,
            ref ExplainedNumber __result)
        {
            int tier = troop.Tier;

            // ---------- 커스텀 티어별 비용 정책 ----------
            float baseCost = tier switch
            {
                0 => 100,
                1 => 100,
                2 => 200,
                3 => 400,
                4 => 1000,
                5 => 2000,
                6 => 1300,
                7 => 1800,
                8 => 2400,
                9 => 3200,
                10 => 4200,
                11 => 5500,   // ← 11티어 비용
                12 => 7000,   // ← 11티어 비용
                _ => 9000     // 12 이상 예외처리
            };
            // ------------------------------------------------

            __result = new ExplainedNumber(baseCost, false);

            // 용병/도적/카라반 경비병 추가 비용
            bool isMercType = troop.Occupation == Occupation.Mercenary ||
                              troop.Occupation == Occupation.Gangster ||
                              troop.Occupation == Occupation.CaravanGuard;

            if (isMercType)
                __result.Add(baseCost); // x2 효과

            // --- Perk 적용 (기존 시스템 그대로 유지됨) ---
            if (buyerHero != null)
            {
                if (troop.Tier >= 2 && buyerHero.GetPerkValue(DefaultPerks.Throwing.HeadHunter))
                    __result.AddFactor(DefaultPerks.Throwing.HeadHunter.SecondaryBonus);

                if (troop.IsInfantry)
                {
                    if (buyerHero.GetPerkValue(DefaultPerks.OneHanded.ChinkInTheArmor))
                        __result.AddFactor(DefaultPerks.OneHanded.ChinkInTheArmor.SecondaryBonus);
                }

                if (isMercType)
                {
                    if (buyerHero.GetPerkValue(DefaultPerks.Trade.SwordForBarter))
                        __result.AddFactor(DefaultPerks.Trade.SwordForBarter.PrimaryBonus);
                }

                __result.LimitMin(1f);
            }

            return false; // 원본 실행하지 않음
        }
    }

    // 업그레이드 비용 패치
    [HarmonyPatch(typeof(DefaultPartyTroopUpgradeModel))]
    public static class UpgradeCostPatch
    {
        [HarmonyPrefix]
        [HarmonyPatch("GetGoldCostForUpgrade")]
        public static bool Prefix_GetGoldCostForUpgrade(
            PartyBase party,
            CharacterObject characterObject,
            CharacterObject upgradeTarget,
            ref ExplainedNumber __result)
        {
            if (characterObject == null || upgradeTarget == null)
                return true;

            int fromTier = characterObject.Tier;
            int toTier = upgradeTarget.Tier;

            if (toTier <= fromTier)
                return true;

            float cost = (fromTier, toTier) switch
            {
                (1, 2) => 100f,
                (2, 3) => 200f,
                (3, 4) => 400f,
                (4, 5) => 1000f,
                (5, 6) => 2000f,
                (6, 7) => 5000f,
                (7, 8) => 10000f,
                (8, 9) => 20000f,
                (9, 10) => 50000f,
                (10, 11) => 100000f,
                _ => 300000f
            };

            __result = new ExplainedNumber(cost, false);
            return false; // 원본 실행 안 함
        }
    }


    // ==========================================
    //  DefaultCharacterStatsModel.MaxHitpoints 패치
    //  티어 기반 체력 완전 재정의
    // ==========================================
    [HarmonyPatch(typeof(DefaultCharacterStatsModel), "MaxHitpoints")]
    public class Patch_MaxHitpoints_ByTier
    {
        // 티어별 체력 테이블
        private static readonly Dictionary<int, float> TierHealth = new Dictionary<int, float>
    {
        { 1, 100 },
        { 2, 110 },
        { 3, 120 },
        { 4, 130 },
        { 5, 140 },
        { 6, 150 },
        { 7, 180 },
        { 8, 220 },
        { 9, 300 },
        { 10, 600 },
        { 11, 2000 },
        { 12, 2500 }
    };

        static bool Prefix(
            CharacterObject character,
            bool includeDescriptions,
            ref ExplainedNumber __result,
            DefaultCharacterStatsModel __instance
        )
        {
            try
            {
                int tier = character.Tier;

                // 잘못된 티어 값 보호
                if (tier < 1) tier = 1;
                if (tier > 12) tier = 12;

                float baseHealth = TierHealth[tier];

                // 플레이어/영웅 기본체력
                if (character.IsPlayerCharacter){baseHealth = 200;}
                else if (character.IsHero){baseHealth = 200;}

                ExplainedNumber result = new ExplainedNumber(baseHealth, includeDescriptions);

                // perks 적용
                if (character.IsHero || character.IsPlayerCharacter)
                {
                    //Trace.WriteLine("[TroopTierTweaks] Patch_MaxHitpoints_ByTier1 ");
                    result.Add(DefaultPerks.Medicine.FortitudeTonic.PrimaryBonus, DefaultPerks.Medicine.FortitudeTonic.Name, null);
                }
                if (character.GetPerkValue(DefaultPerks.Athletics.MightyBlow))
                {
                    //Trace.WriteLine("[TroopTierTweaks] Patch_MaxHitpoints_ByTier2 ");
                    int num = character.GetSkillValue(DefaultSkills.Athletics) - Campaign.Current.Models.CharacterDevelopmentModel.MaxSkillRequiredForEpicPerkBonus;
                    result.Add((float)num, DefaultPerks.Athletics.MightyBlow.Name, null);
                }

                if (tier >= 10)
                {
                    //Trace.WriteLine($"[TroopTierTweaks] MaxHP: {character.Name} (Tier {tier}) = {baseHealth}" + ", LimitMinValue " + result.LimitMinValue);
                }
                __result = result;
                return false; // 원본 실행 막기
            }
            catch (Exception e)
            {
                Trace.WriteLine("[TroopTierTweaks] MaxHitpoints patch error: " + e);
                return true; // 에러 시 원본 실행
            }
        }
    }

    // 전투력 증가
    [HarmonyPatch(typeof(DefaultMilitaryPowerModel), "GetTroopPower")]
    public static class Patch_TroopPower_TierBoost
    {
        [HarmonyPostfix]
        public static void Postfix(CharacterObject troop, ref float __result)
        {
            int tier = troop.Tier;
            float tierMultiplier = tier switch
            {
                >= 10 => 3.0f,
                9 => 1.5f,
                8 => 1.4f,
                7 => 1.3f,
                6 => 1.1f,
                5 => 1.0f,
                4 => 1.0f,
                _ => 1.0f
            };
            __result *= tierMultiplier;
            //Trace.WriteLine($"[TroopTierTweaks] {troop.Name} power boosted: {__result}");
        }
    }

    // 사망률 감소
    [HarmonyPatch]
    public static class Patch_DeathRate_TierReduce
    {
        static System.Reflection.MethodBase TargetMethod()
        {
            // CharacterObject용 SimulateHit 오버로드 명시
            return AccessTools.Method(
                typeof(DefaultCombatSimulationModel),
                "SimulateHit",
                new Type[]
                {
                typeof(CharacterObject), // strikerTroop
                typeof(CharacterObject), // struckTroop
                typeof(PartyBase),       // strikerParty
                typeof(PartyBase),       // struckParty
                typeof(float),           // strikerAdvantage
                typeof(MapEvent),        // battle
                typeof(float),           // strikerSideMorale
                typeof(float)            // struckSideMorale
                });
        }

        [HarmonyPostfix]
        public static void Postfix(CharacterObject strikerTroop, CharacterObject struckTroop, ref ExplainedNumber __result)
        {
            int tier = struckTroop.Tier;
            float deathMult = tier switch
            {
                >= 10 => 0.10f,
                9 => 0.45f,
                8 => 0.60f,
                7 => 0.80f,
                6 => 0.90f,
                _ => 1.0f
            };

            __result = new ExplainedNumber(__result.ResultNumber * deathMult, false, null);
        }

    }

}