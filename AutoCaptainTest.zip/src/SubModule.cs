﻿using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using TaleWorlds.Core;
using TaleWorlds.InputSystem;
using TaleWorlds.MountAndBlade;

namespace AutoCaptainTest
{
    public class SubModule : MBSubModuleBase
    {
        protected override void OnSubModuleLoad()
        {
            base.OnSubModuleLoad();
            try
            {
                var harmony = new Harmony("AutoCaptainTest");
                harmony.PatchAll();
                Trace.WriteLine("[AutoCaptainTest] Harmony patches applied");
            }
            catch (Exception ex)
            {
                Trace.WriteLine("[AutoCaptainTest] Harmony patch error: " + ex);
            }
        }
    }

    [HarmonyPatch(typeof(DeploymentMissionController), "OnMissionTick")]
    public class DeploymentMissionController_OnMissionTick_Patch
    {
        static Dictionary<DeploymentMissionController, bool> _assignedPerMission = new();

        static void Postfix(DeploymentMissionController __instance, float dt)
        {
            try
            {
                var mission = Mission.Current;
                if (mission == null || mission.Teams == null) return;
                if (!__instance.TeamSetupOver) return;

                // 전투가 바뀌면 초기화
                if (!_assignedPerMission.ContainsKey(__instance))
                    _assignedPerMission[__instance] = false;

                if (!_assignedPerMission[__instance])
                {
                    // 동맹군 없는 경우 세팅 안 함
                    bool playerAllyTeamCheck = mission.Teams.Any(team => team.TeamSide.ToString() == "PlayerAllyTeam");
                    if (playerAllyTeamCheck)
                    {
                        // 내 팀만 처리
                        var playerTeam = mission.Teams.FirstOrDefault(t => t.IsPlayerTeam);
                        if (playerTeam != null)
                        {
                            // 내 팀 영웅 리스트 (플레이어 제외)
                            List<Agent> heroes = playerTeam.ActiveAgents
                                .Where(a => a.Character != null && a.Character.IsHero && a != mission.MainAgent)
                                .ToList();

                            foreach (var formation in playerTeam.FormationsIncludingEmpty)
                            {
                                if (formation.CountOfUnits == 0) continue;

                                if (formation == playerTeam.GetFormation(0))
                                {
                                    // 1번 포메이션 → 플레이어 Captain
                                    formation.Captain = mission.MainAgent;
                                }
                                else
                                {
                                    if (heroes.Count == 0) break;

                                    var hero = heroes[0];
                                    heroes.RemoveAt(0);

                                    formation.Captain = hero;
                                }
                            }

                            _assignedPerMission[__instance] = true;
                        }
                    }
                }

                // =============================
                // 배치 화면에서 V 키로 준비 버튼 실행
                // =============================
                if (Input.IsKeyPressed(InputKey.V))
                {
                    Trace.WriteLine("[AutoCaptainTest] Hotkey V pressed, triggering Prepare button1");
                    var controller = mission.GetMissionBehavior<DeploymentMissionController>();
                    if (controller != null && controller.TeamSetupOver)
                    {
                        Trace.WriteLine("[AutoCaptainTest] Hotkey V pressed, triggering Prepare button2");
                        controller.FinishDeployment();
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine("[AutoCaptainTest] Exception in OnMissionTick: " + ex);
            }
        }
    }
}
